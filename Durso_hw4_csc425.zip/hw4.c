#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>

#define FILE_SIZE 38576

int main() {
    int fd_image, fd_colors1, fd_colors2, fd_colors3;
    char *image_body, *colors1, *colors2, *colors3;
    
    fd_image = open("image-body.txt", O_RDONLY);
    fd_colors1 = open("colors1.txt", O_RDONLY);
    fd_colors2 = open("colors2.txt", O_RDONLY);
    fd_colors3 = open("colors3.txt", O_RDONLY);

    image_body = mmap(NULL, FILE_SIZE, PROT_READ, MAP_SHARED, fd_image, 0);
    colors1 = mmap(NULL, FILE_SIZE, PROT_READ, MAP_SHARED, fd_colors1, 0);
    colors2 = mmap(NULL, FILE_SIZE, PROT_READ, MAP_SHARED, fd_colors2, 0);
    colors3 = mmap(NULL, FILE_SIZE, PROT_READ, MAP_SHARED, fd_colors3, 0);

    if (fork() == 0) {
        int fd = open("image1.xpm", O_WRONLY | O_CREAT | O_TRUNC, 0644);
        write(fd, colors1, 270);
        write(fd, image_body, 38306);
        close(fd);
        _exit(0);
    }

    if (fork() == 0) {
        int fd = open("image2.xpm", O_WRONLY | O_CREAT | O_TRUNC, 0644);
        write(fd, colors2, 270);
        write(fd, image_body, 38306);
        close(fd);
        _exit(0);
    }

    if (fork() == 0) {
        int fd = open("image3.xpm", O_WRONLY | O_CREAT | O_TRUNC, 0644);
        write(fd, colors3, 270);
        write(fd, image_body, 38306);
        close(fd);
        _exit(0);
    }

    close(fd_image);
    close(fd_colors1);
    close(fd_colors2);
    close(fd_colors3);
    munmap(image_body, FILE_SIZE);
    munmap(colors1, FILE_SIZE);
    munmap(colors2, FILE_SIZE);
    munmap(colors3, FILE_SIZE);

    return 0;
}
