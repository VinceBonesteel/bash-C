#include <fcntl.h> /* for open */
#include <unistd.h>  /* for read, write, close */

int main() {

   int source = open("alice.xpm", O_RDONLY);
   int alice1 = open("alice1.xpm", O_WRONLY | O_CREAT, S_IRUSR | S_IWUSR);
   int alice2 = open("alice2.xpm", O_WRONLY | O_CREAT, S_IRUSR | S_IWUSR);
   int alice3 = open("alice3.xpm", O_WRONLY | O_CREAT, S_IRUSR | S_IWUSR);

   int start = 0;
   int size = 515056;
   char bytes[size];

   char dot = 46; /* ASCII for . */
   char z = 122; /* ASCII for z */

   for (int i =0; i < size; i++) {
      read(source, &bytes[i], 1);
      if (i > 1 && bytes[i-1] == dot && bytes[i] == dot && start == 0) 
         start = i-1;
   }

   for (int i = 0; i < start; i++) {
      write(alice1, &bytes[i], 1); 
      write(alice2, &bytes[i], 1); 
      write(alice3, &bytes[i], 1); 
   }

   for (int i = start; i < size; i++) {
      if (bytes[i] == dot)
         write(alice1, &z, 1);
      else
         write(alice1, &bytes[i], 1);
   }

   for (int i = start + 1; i < size; i += 2) {
      if (bytes[i-1] == dot && bytes[i] == dot) {
         write(alice2, &dot, 1);
         write(alice2, &z, 1);
      } else {
         write(alice2, &bytes[i-1], 1);
         write(alice2, &bytes[i], 1);
      }
   }

   for (int i = start + 2; i < size; i += 3) {
      if (bytes[i-2] == dot && bytes[i-1] == dot && bytes[i] == dot) {
      	 write(alice3, &dot, 1);
         write(alice3, &dot, 1);
         write(alice3, &z, 1);
      } else {
         write(alice3, &bytes[i-2], 1);
         write(alice3, &bytes[i-1], 1);
         write(alice3, &bytes[i], 1);
      }
   }
   
   close(source);
   close(alice1);
   close(alice2);
   close(alice3);
   

   

} //main
